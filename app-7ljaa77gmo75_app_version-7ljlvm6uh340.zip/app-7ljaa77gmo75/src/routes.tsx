import Dashboard from './pages/Dashboard';
import Devices from './pages/Devices';
import Schedules from './pages/Schedules';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: <Dashboard />
  },
  {
    name: 'Devices',
    path: '/devices',
    element: <Devices />
  },
  {
    name: 'Schedules',
    path: '/schedules',
    element: <Schedules />
  },
  {
    name: 'Reports',
    path: '/reports',
    element: <Reports />
  },
  {
    name: 'Settings',
    path: '/settings',
    element: <Settings />
  }
];

export default routes;