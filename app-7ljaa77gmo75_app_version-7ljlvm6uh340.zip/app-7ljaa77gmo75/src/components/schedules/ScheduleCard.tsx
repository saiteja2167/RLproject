import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Calendar, Settings, Trash2 } from "lucide-react";
import type { DeviceSchedule, Device } from "@/types/types";

interface ScheduleCardProps {
  schedule: DeviceSchedule;
  device?: Device;
  onToggle: (scheduleId: string, isEnabled: boolean) => void;
  onEdit: (schedule: DeviceSchedule) => void;
  onDelete: (scheduleId: string) => void;
}

export default function ScheduleCard({ 
  schedule, 
  device,
  onToggle, 
  onEdit, 
  onDelete 
}: ScheduleCardProps) {
  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = Number.parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0 && mins > 0) return `${hours}h ${mins}m`;
    if (hours > 0) return `${hours}h`;
    return `${mins}m`;
  };

  const dayAbbreviations: Record<string, string> = {
    monday: 'Mon',
    tuesday: 'Tue',
    wednesday: 'Wed',
    thursday: 'Thu',
    friday: 'Fri',
    saturday: 'Sat',
    sunday: 'Sun',
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="font-semibold text-lg">{schedule.schedule_name}</h3>
            {device && (
              <p className="text-sm text-muted-foreground mt-1">{device.name}</p>
            )}
          </div>
          
          <Switch
            checked={schedule.is_enabled}
            onCheckedChange={(checked) => onToggle(schedule.id, checked)}
          />
        </div>
        
        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-2 text-sm">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <span className="font-medium">{formatTime(schedule.start_time)}</span>
            <span className="text-muted-foreground">•</span>
            <span className="text-muted-foreground">{formatDuration(schedule.duration_minutes)}</span>
          </div>
          
          <div className="flex items-start gap-2">
            <Calendar className="w-4 h-4 text-muted-foreground mt-0.5" />
            <div className="flex flex-wrap gap-1">
              {schedule.days_of_week.map((day) => (
                <Badge key={day} variant="secondary" className="text-xs">
                  {dayAbbreviations[day]}
                </Badge>
              ))}
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onEdit(schedule)}
          >
            <Settings className="w-4 h-4 mr-2" />
            Edit
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDelete(schedule.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
