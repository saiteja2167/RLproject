import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import type { Device, DeviceSchedule } from "@/types/types";

interface ScheduleFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  devices: Device[];
  schedule?: DeviceSchedule | null;
  onSave: (schedule: Partial<DeviceSchedule>) => void;
}

const daysOfWeek = [
  { value: "monday", label: "Monday" },
  { value: "tuesday", label: "Tuesday" },
  { value: "wednesday", label: "Wednesday" },
  { value: "thursday", label: "Thursday" },
  { value: "friday", label: "Friday" },
  { value: "saturday", label: "Saturday" },
  { value: "sunday", label: "Sunday" },
];

export default function ScheduleFormDialog({ 
  open, 
  onOpenChange, 
  devices,
  schedule, 
  onSave 
}: ScheduleFormDialogProps) {
  const [formData, setFormData] = useState({
    schedule_name: "",
    device_id: "",
    start_time: "",
    duration_minutes: "",
    days_of_week: [] as string[],
    is_enabled: true,
  });

  const schedulableDevices = devices.filter(d => d.is_schedulable);

  useEffect(() => {
    if (schedule) {
      setFormData({
        schedule_name: schedule.schedule_name,
        device_id: schedule.device_id,
        start_time: schedule.start_time,
        duration_minutes: schedule.duration_minutes.toString(),
        days_of_week: schedule.days_of_week,
        is_enabled: schedule.is_enabled,
      });
    } else {
      setFormData({
        schedule_name: "",
        device_id: schedulableDevices[0]?.id || "",
        start_time: "",
        duration_minutes: "",
        days_of_week: [],
        is_enabled: true,
      });
    }
  }, [schedule, open, schedulableDevices]);

  const handleDayToggle = (day: string) => {
    setFormData(prev => ({
      ...prev,
      days_of_week: prev.days_of_week.includes(day)
        ? prev.days_of_week.filter(d => d !== day)
        : [...prev.days_of_week, day]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.days_of_week.length === 0) {
      alert("Please select at least one day");
      return;
    }

    const duration = Number.parseInt(formData.duration_minutes);
    if (Number.isNaN(duration) || duration <= 0) {
      alert("Please enter a valid duration");
      return;
    }

    onSave({
      ...(schedule ? { id: schedule.id } : {}),
      schedule_name: formData.schedule_name,
      device_id: formData.device_id,
      start_time: formData.start_time,
      duration_minutes: duration,
      days_of_week: formData.days_of_week,
      is_enabled: formData.is_enabled,
    });
    
    onOpenChange(false);
  };

  if (schedulableDevices.length === 0) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>No Schedulable Devices</DialogTitle>
          </DialogHeader>
          <p className="text-muted-foreground">
            You need to add schedulable devices before creating schedules.
          </p>
          <DialogFooter>
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{schedule ? "Edit Schedule" : "Create New Schedule"}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="schedule_name">Schedule Name</Label>
            <Input
              id="schedule_name"
              value={formData.schedule_name}
              onChange={(e) => setFormData({ ...formData, schedule_name: e.target.value })}
              placeholder="e.g., Night Washing"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="device_id">Device</Label>
            <Select
              value={formData.device_id}
              onValueChange={(value) => setFormData({ ...formData, device_id: value })}
            >
              <SelectTrigger id="device_id">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {schedulableDevices.map((device) => (
                  <SelectItem key={device.id} value={device.id}>
                    {device.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="start_time">Start Time</Label>
            <Input
              id="start_time"
              type="time"
              value={formData.start_time}
              onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration_minutes">Duration (minutes)</Label>
            <Input
              id="duration_minutes"
              type="number"
              min="1"
              value={formData.duration_minutes}
              onChange={(e) => setFormData({ ...formData, duration_minutes: e.target.value })}
              placeholder="e.g., 60"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Days of Week</Label>
            <div className="grid grid-cols-2 gap-3">
              {daysOfWeek.map((day) => (
                <div key={day.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={day.value}
                    checked={formData.days_of_week.includes(day.value)}
                    onCheckedChange={() => handleDayToggle(day.value)}
                  />
                  <Label htmlFor={day.value} className="cursor-pointer">
                    {day.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="is_enabled">Enabled</Label>
            <Switch
              id="is_enabled"
              checked={formData.is_enabled}
              onCheckedChange={(checked) => setFormData({ ...formData, is_enabled: checked })}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {schedule ? "Update" : "Create"} Schedule
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
