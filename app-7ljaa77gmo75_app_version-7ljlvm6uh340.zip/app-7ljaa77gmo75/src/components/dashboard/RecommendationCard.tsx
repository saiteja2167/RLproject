import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, TrendingDown, X } from "lucide-react";
import type { Recommendation } from "@/types/types";

interface RecommendationCardProps {
  recommendation: Recommendation;
  onDismiss: (id: string) => void;
}

export default function RecommendationCard({ 
  recommendation, 
  onDismiss 
}: RecommendationCardProps) {
  const priorityColors = {
    high: "border-destructive bg-destructive/5",
    medium: "border-accent bg-accent/5",
    low: "border-info bg-info/5",
  };

  const priorityIcons = {
    high: AlertCircle,
    medium: TrendingDown,
    low: TrendingDown,
  };

  const Icon = priorityIcons[recommendation.priority];

  return (
    <Card className={`${priorityColors[recommendation.priority]} border-l-4`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <Icon className={`w-5 h-5 mt-0.5 ${
              recommendation.priority === 'high' ? 'text-destructive' :
              recommendation.priority === 'medium' ? 'text-accent' :
              'text-info'
            }`} />
            <div className="flex-1">
              <h4 className="font-semibold mb-1">{recommendation.title}</h4>
              <p className="text-sm text-muted-foreground mb-2">
                {recommendation.description}
              </p>
              {recommendation.potential_savings && (
                <p className="text-sm font-medium text-secondary">
                  Potential savings: ${recommendation.potential_savings.toFixed(2)}/month
                </p>
              )}
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => onDismiss(recommendation.id)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
