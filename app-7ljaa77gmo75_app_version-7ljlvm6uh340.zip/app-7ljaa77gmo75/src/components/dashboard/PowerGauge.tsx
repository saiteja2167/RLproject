import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface PowerGaugeProps {
  currentPower: number;
  maxPower?: number;
  isPeakHour: boolean;
}

export default function PowerGauge({ 
  currentPower, 
  maxPower = 10,
  isPeakHour 
}: PowerGaugeProps) {
  const percentage = Math.min((currentPower / maxPower) * 100, 100);
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Current Power Usage</span>
          {isPeakHour && (
            <span className="text-xs font-normal px-2 py-1 rounded-full bg-accent text-accent-foreground">
              Peak Hour
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <div className="text-5xl font-bold text-primary">
            {currentPower.toFixed(2)}
          </div>
          <div className="text-sm text-muted-foreground mt-1">kW</div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Usage</span>
            <span className="font-medium">{percentage.toFixed(0)}%</span>
          </div>
          <Progress 
            value={percentage} 
            className="h-3"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0 kW</span>
            <span>{maxPower} kW</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
