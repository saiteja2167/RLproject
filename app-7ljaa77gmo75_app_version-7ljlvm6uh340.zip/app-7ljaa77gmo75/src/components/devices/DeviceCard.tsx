import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { 
  AirVent, 
  Droplet, 
  Car, 
  WashingMachine, 
  Wind, 
  Utensils, 
  Waves, 
  Lightbulb,
  Zap,
  Settings,
  Trash2
} from "lucide-react";
import type { Device, DeviceType } from "@/types/types";

interface DeviceCardProps {
  device: Device;
  onToggle: (deviceId: string, isActive: boolean) => void;
  onEdit: (device: Device) => void;
  onDelete: (deviceId: string) => void;
}

const deviceIcons: Record<DeviceType, typeof Zap> = {
  hvac: AirVent,
  water_heater: Droplet,
  ev_charger: Car,
  washer: WashingMachine,
  dryer: Wind,
  dishwasher: Utensils,
  pool_pump: Waves,
  lighting: Lightbulb,
  other: Zap,
};

export default function DeviceCard({ device, onToggle, onEdit, onDelete }: DeviceCardProps) {
  const Icon = deviceIcons[device.device_type];
  
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-lg ${device.is_active ? 'bg-primary/10' : 'bg-muted'}`}>
              <Icon className={`w-6 h-6 ${device.is_active ? 'text-primary' : 'text-muted-foreground'}`} />
            </div>
            <div>
              <h3 className="font-semibold text-lg">{device.name}</h3>
              <p className="text-sm text-muted-foreground capitalize">
                {device.device_type.replace('_', ' ')}
              </p>
            </div>
          </div>
          
          <Switch
            checked={device.is_active}
            onCheckedChange={(checked) => onToggle(device.id, checked)}
          />
        </div>
        
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Power Rating</span>
            <span className="font-medium">{device.power_rating} kW</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Status</span>
            <span className={`font-medium ${device.is_active ? 'text-success' : 'text-muted-foreground'}`}>
              {device.is_active ? 'Active' : 'Inactive'}
            </span>
          </div>
          {device.is_schedulable && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Schedulable</span>
              <span className="font-medium text-secondary">Yes</span>
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onEdit(device)}
          >
            <Settings className="w-4 h-4 mr-2" />
            Edit
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDelete(device.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
