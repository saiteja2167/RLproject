import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import type { Device, DeviceType } from "@/types/types";

interface DeviceFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  device?: Device | null;
  onSave: (device: Partial<Device>) => void;
}

const deviceTypes: { value: DeviceType; label: string }[] = [
  { value: "hvac", label: "HVAC" },
  { value: "water_heater", label: "Water Heater" },
  { value: "ev_charger", label: "EV Charger" },
  { value: "washer", label: "Washer" },
  { value: "dryer", label: "Dryer" },
  { value: "dishwasher", label: "Dishwasher" },
  { value: "pool_pump", label: "Pool Pump" },
  { value: "lighting", label: "Lighting" },
  { value: "other", label: "Other" },
];

export default function DeviceFormDialog({ 
  open, 
  onOpenChange, 
  device, 
  onSave 
}: DeviceFormDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    device_type: "other" as DeviceType,
    power_rating: "",
    is_active: true,
    is_schedulable: true,
  });

  useEffect(() => {
    if (device) {
      setFormData({
        name: device.name,
        device_type: device.device_type,
        power_rating: device.power_rating.toString(),
        is_active: device.is_active,
        is_schedulable: device.is_schedulable,
      });
    } else {
      setFormData({
        name: "",
        device_type: "other",
        power_rating: "",
        is_active: true,
        is_schedulable: true,
      });
    }
  }, [device, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const powerRating = Number.parseFloat(formData.power_rating);
    if (Number.isNaN(powerRating) || powerRating <= 0) {
      alert("Please enter a valid power rating");
      return;
    }

    onSave({
      ...(device ? { id: device.id } : {}),
      name: formData.name,
      device_type: formData.device_type,
      power_rating: powerRating,
      is_active: formData.is_active,
      is_schedulable: formData.is_schedulable,
    });
    
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{device ? "Edit Device" : "Add New Device"}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Device Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Living Room AC"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="device_type">Device Type</Label>
            <Select
              value={formData.device_type}
              onValueChange={(value) => setFormData({ ...formData, device_type: value as DeviceType })}
            >
              <SelectTrigger id="device_type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {deviceTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="power_rating">Power Rating (kW)</Label>
            <Input
              id="power_rating"
              type="number"
              step="0.1"
              min="0.1"
              value={formData.power_rating}
              onChange={(e) => setFormData({ ...formData, power_rating: e.target.value })}
              placeholder="e.g., 2.5"
              required
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="is_active">Active</Label>
            <Switch
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="is_schedulable">Schedulable</Label>
            <Switch
              id="is_schedulable"
              checked={formData.is_schedulable}
              onCheckedChange={(checked) => setFormData({ ...formData, is_schedulable: checked })}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {device ? "Update" : "Add"} Device
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
