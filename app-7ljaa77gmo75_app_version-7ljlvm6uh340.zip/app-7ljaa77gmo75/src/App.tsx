import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import PageMeta from '@/components/common/PageMeta';
import routes from './routes';

const App: React.FC = () => {
  return (
    <>
      <PageMeta 
        title="Smart Grid Energy Optimizer" 
        description="Monitor and optimize your electricity consumption with intelligent device scheduling and real-time analytics"
      />
      <Router>
        <DashboardLayout>
          <Routes>
            {routes.map((route, index) => (
              <Route
                key={index}
                path={route.path}
                element={route.element}
              />
            ))}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </DashboardLayout>
      </Router>
    </>
  );
};

export default App;
