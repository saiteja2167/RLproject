import { useState, useEffect } from "react";
import { getUserId, getUserProfile, createUserProfile } from "@/db/api";
import { supabase } from "@/db/supabase";
import type { UserProfile } from "@/types/types";

const createSampleRecommendations = async (userId: string) => {
  const { data: existing } = await supabase
    .from("recommendations")
    .select("id")
    .eq("user_id", userId)
    .limit(1);

  if (existing && existing.length > 0) return;

  const recommendations = [
    {
      user_id: userId,
      title: "Schedule Water Heater During Off-Peak Hours",
      description: "Your water heater consumes significant power during peak hours. Consider scheduling it to run between 10 PM and 6 AM to save on electricity costs.",
      priority: "high",
      potential_savings: 35.50,
    },
    {
      user_id: userId,
      title: "Enable Smart Scheduling for EV Charging",
      description: "Charging your electric vehicle during off-peak hours can reduce costs by up to 50%. Set up automatic scheduling to optimize charging times.",
      priority: "medium",
      potential_savings: 42.00,
    },
    {
      user_id: userId,
      title: "Reduce HVAC Usage During Peak Hours",
      description: "Pre-cool or pre-heat your home before peak hours begin. This can maintain comfort while reducing peak-hour energy consumption.",
      priority: "medium",
      potential_savings: 28.75,
    },
  ];

  await supabase.from("recommendations").insert(recommendations);
};

export const useUser = () => {
  const [userId, setUserId] = useState<string>("");
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initUser = async () => {
      try {
        setLoading(true);
        const id = getUserId();
        setUserId(id);

        let profile = await getUserProfile(id);
        if (!profile) {
          profile = await createUserProfile(id);
          await createSampleRecommendations(id);
        }
        setUserProfile(profile);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to initialize user");
      } finally {
        setLoading(false);
      }
    };

    initUser();
  }, []);

  return { userId, userProfile, loading, error, setUserProfile };
};
