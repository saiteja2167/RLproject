import { useState, useEffect } from "react";
import { useUser } from "@/hooks/use-user";
import { 
  getDevices, 
  getRecommendations, 
  dismissRecommendation,
  getConsumptionHistory 
} from "@/db/api";
import StatCard from "@/components/dashboard/StatCard";
import PowerGauge from "@/components/dashboard/PowerGauge";
import ConsumptionChart from "@/components/dashboard/ConsumptionChart";
import RecommendationCard from "@/components/dashboard/RecommendationCard";
import { Zap, DollarSign, TrendingDown, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Device, Recommendation } from "@/types/types";

export default function Dashboard() {
  const { userId, userProfile, loading: userLoading } = useUser();
  const { toast } = useToast();
  const [devices, setDevices] = useState<Device[]>([]);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [currentPower, setCurrentPower] = useState(0);
  const [chartData, setChartData] = useState<Array<{ time: string; power: number; isPeakHour: boolean }>>([]);
  const [loading, setLoading] = useState(true);

  const isPeakHour = () => {
    if (!userProfile) return false;
    const hour = new Date().getHours();
    return hour >= userProfile.peak_hours_start && hour < userProfile.peak_hours_end;
  };

  useEffect(() => {
    if (!userId) return;

    const loadData = async () => {
      try {
        setLoading(true);
        const [devicesData, recommendationsData] = await Promise.all([
          getDevices(userId),
          getRecommendations(userId),
        ]);
        
        setDevices(devicesData);
        setRecommendations(recommendationsData);
        
        const activeDevices = devicesData.filter(d => d.is_active);
        const totalPower = activeDevices.reduce((sum, d) => sum + d.power_rating, 0);
        setCurrentPower(totalPower);
        
        generateChartData();
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load dashboard data",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [userId]);

  useEffect(() => {
    const interval = setInterval(() => {
      const activeDevices = devices.filter(d => d.is_active);
      const basePower = activeDevices.reduce((sum, d) => sum + d.power_rating, 0);
      const variation = (Math.random() - 0.5) * 0.5;
      setCurrentPower(Math.max(0, basePower + variation));
    }, 3000);

    return () => clearInterval(interval);
  }, [devices]);

  const generateChartData = () => {
    const data = [];
    const now = new Date();
    
    for (let i = 23; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 60 * 60 * 1000);
      const hour = time.getHours();
      const isPeak = userProfile ? 
        hour >= userProfile.peak_hours_start && hour < userProfile.peak_hours_end : 
        false;
      
      const basePower = isPeak ? 3 + Math.random() * 3 : 1.5 + Math.random() * 2;
      
      data.push({
        time: `${hour.toString().padStart(2, '0')}:00`,
        power: Number.parseFloat(basePower.toFixed(2)),
        isPeakHour: isPeak,
      });
    }
    
    setChartData(data);
  };

  const handleDismissRecommendation = async (id: string) => {
    try {
      await dismissRecommendation(id);
      setRecommendations(recommendations.filter(r => r.id !== id));
      toast({
        title: "Success",
        description: "Recommendation dismissed",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to dismiss recommendation",
        variant: "destructive",
      });
    }
  };

  const calculateStats = () => {
    const todayEnergy = chartData.reduce((sum, d) => sum + d.power, 0);
    const peakRate = userProfile?.electricity_rate_peak || 0.25;
    const offPeakRate = userProfile?.electricity_rate_offpeak || 0.12;
    
    const todayCost = chartData.reduce((sum, d) => {
      const rate = d.isPeakHour ? peakRate : offPeakRate;
      return sum + (d.power * rate);
    }, 0);
    
    const estimatedMonthlyCost = todayCost * 30;
    const activeDevicesCount = devices.filter(d => d.is_active).length;
    const scheduledDevicesCount = devices.filter(d => d.is_schedulable).length;
    
    const potentialSavings = recommendations.reduce((sum, r) => 
      sum + (r.potential_savings || 0), 0
    );

    return {
      todayEnergy: todayEnergy.toFixed(2),
      todayCost: todayCost.toFixed(2),
      estimatedMonthlyCost: estimatedMonthlyCost.toFixed(2),
      activeDevicesCount,
      scheduledDevicesCount,
      potentialSavings: potentialSavings.toFixed(2),
    };
  };

  if (userLoading || loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  const stats = calculateStats();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Monitor your energy consumption and optimize usage
        </p>
      </div>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          title="Today's Energy"
          value={`${stats.todayEnergy} kWh`}
          icon={Zap}
          subtitle="Total consumption"
        />
        <StatCard
          title="Today's Cost"
          value={`$${stats.todayCost}`}
          icon={DollarSign}
          subtitle="Based on current rates"
        />
        <StatCard
          title="Est. Monthly Cost"
          value={`$${stats.estimatedMonthlyCost}`}
          icon={TrendingDown}
          subtitle="Projected from today"
        />
        <StatCard
          title="Active Devices"
          value={stats.activeDevicesCount}
          icon={Calendar}
          subtitle={`${stats.scheduledDevicesCount} schedulable`}
        />
      </div>

      <div className="grid gap-6 grid-cols-1 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <ConsumptionChart data={chartData} />
        </div>
        <div>
          <PowerGauge 
            currentPower={currentPower} 
            isPeakHour={isPeakHour()}
          />
        </div>
      </div>

      {recommendations.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Recommendations</h2>
          <div className="space-y-3">
            {recommendations.map((rec) => (
              <RecommendationCard
                key={rec.id}
                recommendation={rec}
                onDismiss={handleDismissRecommendation}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
