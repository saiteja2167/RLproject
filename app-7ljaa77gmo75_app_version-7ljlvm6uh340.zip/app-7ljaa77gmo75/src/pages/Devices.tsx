import { useState, useEffect } from "react";
import { useUser } from "@/hooks/use-user";
import { getDevices, createDevice, updateDevice, deleteDevice } from "@/db/api";
import DeviceCard from "@/components/devices/DeviceCard";
import DeviceFormDialog from "@/components/devices/DeviceFormDialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Device } from "@/types/types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Devices() {
  const { userId, loading: userLoading } = useUser();
  const { toast } = useToast();
  const [devices, setDevices] = useState<Device[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingDevice, setEditingDevice] = useState<Device | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deviceToDelete, setDeviceToDelete] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;

    const loadDevices = async () => {
      try {
        setLoading(true);
        const data = await getDevices(userId);
        setDevices(data);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load devices",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    loadDevices();
  }, [userId]);

  const handleToggleDevice = async (deviceId: string, isActive: boolean) => {
    try {
      const updated = await updateDevice(deviceId, { is_active: isActive });
      setDevices(devices.map(d => d.id === deviceId ? updated : d));
      toast({
        title: "Success",
        description: `Device ${isActive ? 'activated' : 'deactivated'}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update device",
        variant: "destructive",
      });
    }
  };

  const handleSaveDevice = async (deviceData: Partial<Device>) => {
    try {
      if (editingDevice) {
        const updated = await updateDevice(editingDevice.id, deviceData);
        setDevices(devices.map(d => d.id === editingDevice.id ? updated : d));
        toast({
          title: "Success",
          description: "Device updated successfully",
        });
      } else {
        const newDevice = await createDevice({
          user_id: userId,
          name: deviceData.name!,
          device_type: deviceData.device_type!,
          power_rating: deviceData.power_rating!,
          is_active: deviceData.is_active ?? true,
          is_schedulable: deviceData.is_schedulable ?? true,
        });
        setDevices([...devices, newDevice]);
        toast({
          title: "Success",
          description: "Device added successfully",
        });
      }
      setEditingDevice(null);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${editingDevice ? 'update' : 'add'} device`,
        variant: "destructive",
      });
    }
  };

  const handleDeleteDevice = async () => {
    if (!deviceToDelete) return;

    try {
      await deleteDevice(deviceToDelete);
      setDevices(devices.filter(d => d.id !== deviceToDelete));
      toast({
        title: "Success",
        description: "Device deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete device",
        variant: "destructive",
      });
    } finally {
      setDeleteDialogOpen(false);
      setDeviceToDelete(null);
    }
  };

  const handleEditDevice = (device: Device) => {
    setEditingDevice(device);
    setDialogOpen(true);
  };

  const handleAddDevice = () => {
    setEditingDevice(null);
    setDialogOpen(true);
  };

  const confirmDelete = (deviceId: string) => {
    setDeviceToDelete(deviceId);
    setDeleteDialogOpen(true);
  };

  if (userLoading || loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Devices</h1>
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-64 bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Devices</h1>
          <p className="text-muted-foreground mt-1">
            Manage your smart devices and appliances
          </p>
        </div>
        <Button onClick={handleAddDevice}>
          <Plus className="w-4 h-4 mr-2" />
          Add Device
        </Button>
      </div>

      {devices.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No devices added yet</p>
          <Button onClick={handleAddDevice}>
            <Plus className="w-4 h-4 mr-2" />
            Add Your First Device
          </Button>
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
          {devices.map((device) => (
            <DeviceCard
              key={device.id}
              device={device}
              onToggle={handleToggleDevice}
              onEdit={handleEditDevice}
              onDelete={confirmDelete}
            />
          ))}
        </div>
      )}

      <DeviceFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        device={editingDevice}
        onSave={handleSaveDevice}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Device</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this device? This action cannot be undone.
              All associated schedules will also be deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteDevice}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
