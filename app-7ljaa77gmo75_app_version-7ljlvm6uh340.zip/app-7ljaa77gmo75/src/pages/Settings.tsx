import { useState, useEffect } from "react";
import { useUser } from "@/hooks/use-user";
import { updateUserProfile } from "@/db/api";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";

export default function Settings() {
  const { userId, userProfile, loading: userLoading, setUserProfile } = useUser();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    electricity_rate_peak: "",
    electricity_rate_offpeak: "",
    peak_hours_start: "",
    peak_hours_end: "",
    monthly_budget: "",
  });

  useEffect(() => {
    if (userProfile) {
      setFormData({
        electricity_rate_peak: userProfile.electricity_rate_peak.toString(),
        electricity_rate_offpeak: userProfile.electricity_rate_offpeak.toString(),
        peak_hours_start: userProfile.peak_hours_start.toString(),
        peak_hours_end: userProfile.peak_hours_end.toString(),
        monthly_budget: userProfile.monthly_budget?.toString() || "",
      });
    }
  }, [userProfile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const peakRate = Number.parseFloat(formData.electricity_rate_peak);
    const offPeakRate = Number.parseFloat(formData.electricity_rate_offpeak);
    const peakStart = Number.parseInt(formData.peak_hours_start);
    const peakEnd = Number.parseInt(formData.peak_hours_end);
    const budget = formData.monthly_budget ? Number.parseFloat(formData.monthly_budget) : null;

    if (Number.isNaN(peakRate) || peakRate <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter a valid peak rate",
        variant: "destructive",
      });
      return;
    }

    if (Number.isNaN(offPeakRate) || offPeakRate <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter a valid off-peak rate",
        variant: "destructive",
      });
      return;
    }

    if (Number.isNaN(peakStart) || peakStart < 0 || peakStart > 23) {
      toast({
        title: "Invalid Input",
        description: "Peak hours start must be between 0 and 23",
        variant: "destructive",
      });
      return;
    }

    if (Number.isNaN(peakEnd) || peakEnd < 0 || peakEnd > 23) {
      toast({
        title: "Invalid Input",
        description: "Peak hours end must be between 0 and 23",
        variant: "destructive",
      });
      return;
    }

    if (budget !== null && (Number.isNaN(budget) || budget <= 0)) {
      toast({
        title: "Invalid Input",
        description: "Please enter a valid monthly budget",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);
      const updated = await updateUserProfile(userId, {
        electricity_rate_peak: peakRate,
        electricity_rate_offpeak: offPeakRate,
        peak_hours_start: peakStart,
        peak_hours_end: peakEnd,
        monthly_budget: budget,
      });
      setUserProfile(updated);
      toast({
        title: "Success",
        description: "Settings updated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Settings</h1>
        <Skeleton className="h-96 bg-muted" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Configure your electricity rates and preferences
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Electricity Rates</CardTitle>
            <CardDescription>
              Set your electricity rates to calculate accurate costs
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="peak_rate">Peak Hour Rate ($/kWh)</Label>
                <Input
                  id="peak_rate"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={formData.electricity_rate_peak}
                  onChange={(e) => setFormData({ ...formData, electricity_rate_peak: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="offpeak_rate">Off-Peak Hour Rate ($/kWh)</Label>
                <Input
                  id="offpeak_rate"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={formData.electricity_rate_offpeak}
                  onChange={(e) => setFormData({ ...formData, electricity_rate_offpeak: e.target.value })}
                  required
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Peak Hours</CardTitle>
            <CardDescription>
              Define when peak hours occur (24-hour format)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="peak_start">Peak Hours Start (0-23)</Label>
                <Input
                  id="peak_start"
                  type="number"
                  min="0"
                  max="23"
                  value={formData.peak_hours_start}
                  onChange={(e) => setFormData({ ...formData, peak_hours_start: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="peak_end">Peak Hours End (0-23)</Label>
                <Input
                  id="peak_end"
                  type="number"
                  min="0"
                  max="23"
                  value={formData.peak_hours_end}
                  onChange={(e) => setFormData({ ...formData, peak_hours_end: e.target.value })}
                  required
                />
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Current: {formData.peak_hours_start}:00 - {formData.peak_hours_end}:00
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Budget</CardTitle>
            <CardDescription>
              Set an optional monthly electricity budget
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="monthly_budget">Monthly Budget ($)</Label>
              <Input
                id="monthly_budget"
                type="number"
                step="0.01"
                min="0"
                value={formData.monthly_budget}
                onChange={(e) => setFormData({ ...formData, monthly_budget: e.target.value })}
                placeholder="Optional"
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={loading}>
            <Save className="w-4 h-4 mr-2" />
            {loading ? "Saving..." : "Save Settings"}
          </Button>
        </div>
      </form>
    </div>
  );
}
