import { useState, useEffect } from "react";
import { useUser } from "@/hooks/use-user";
import { 
  getDevices, 
  getDeviceSchedules, 
  createDeviceSchedule, 
  updateDeviceSchedule, 
  deleteDeviceSchedule 
} from "@/db/api";
import ScheduleCard from "@/components/schedules/ScheduleCard";
import ScheduleFormDialog from "@/components/schedules/ScheduleFormDialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Device, DeviceSchedule } from "@/types/types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Schedules() {
  const { userId, loading: userLoading } = useUser();
  const { toast } = useToast();
  const [devices, setDevices] = useState<Device[]>([]);
  const [schedules, setSchedules] = useState<DeviceSchedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<DeviceSchedule | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [scheduleToDelete, setScheduleToDelete] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;

    const loadData = async () => {
      try {
        setLoading(true);
        const [devicesData, schedulesData] = await Promise.all([
          getDevices(userId),
          getDeviceSchedules(userId),
        ]);
        setDevices(devicesData);
        setSchedules(schedulesData);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load schedules",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [userId]);

  const handleToggleSchedule = async (scheduleId: string, isEnabled: boolean) => {
    try {
      const updated = await updateDeviceSchedule(scheduleId, { is_enabled: isEnabled });
      setSchedules(schedules.map(s => s.id === scheduleId ? updated : s));
      toast({
        title: "Success",
        description: `Schedule ${isEnabled ? 'enabled' : 'disabled'}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update schedule",
        variant: "destructive",
      });
    }
  };

  const handleSaveSchedule = async (scheduleData: Partial<DeviceSchedule>) => {
    try {
      if (editingSchedule) {
        const updated = await updateDeviceSchedule(editingSchedule.id, scheduleData);
        setSchedules(schedules.map(s => s.id === editingSchedule.id ? updated : s));
        toast({
          title: "Success",
          description: "Schedule updated successfully",
        });
      } else {
        const newSchedule = await createDeviceSchedule({
          user_id: userId,
          device_id: scheduleData.device_id!,
          schedule_name: scheduleData.schedule_name!,
          start_time: scheduleData.start_time!,
          duration_minutes: scheduleData.duration_minutes!,
          days_of_week: scheduleData.days_of_week!,
          is_enabled: scheduleData.is_enabled ?? true,
        });
        setSchedules([...schedules, newSchedule]);
        toast({
          title: "Success",
          description: "Schedule created successfully",
        });
      }
      setEditingSchedule(null);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${editingSchedule ? 'update' : 'create'} schedule`,
        variant: "destructive",
      });
    }
  };

  const handleDeleteSchedule = async () => {
    if (!scheduleToDelete) return;

    try {
      await deleteDeviceSchedule(scheduleToDelete);
      setSchedules(schedules.filter(s => s.id !== scheduleToDelete));
      toast({
        title: "Success",
        description: "Schedule deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete schedule",
        variant: "destructive",
      });
    } finally {
      setDeleteDialogOpen(false);
      setScheduleToDelete(null);
    }
  };

  const handleEditSchedule = (schedule: DeviceSchedule) => {
    setEditingSchedule(schedule);
    setDialogOpen(true);
  };

  const handleAddSchedule = () => {
    setEditingSchedule(null);
    setDialogOpen(true);
  };

  const confirmDelete = (scheduleId: string) => {
    setScheduleToDelete(scheduleId);
    setDeleteDialogOpen(true);
  };

  const getDeviceForSchedule = (deviceId: string) => {
    return devices.find(d => d.id === deviceId);
  };

  if (userLoading || loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Schedules</h1>
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-48 bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Schedules</h1>
          <p className="text-muted-foreground mt-1">
            Optimize energy usage by scheduling devices during off-peak hours
          </p>
        </div>
        <Button onClick={handleAddSchedule}>
          <Plus className="w-4 h-4 mr-2" />
          Create Schedule
        </Button>
      </div>

      {schedules.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No schedules created yet</p>
          <Button onClick={handleAddSchedule}>
            <Plus className="w-4 h-4 mr-2" />
            Create Your First Schedule
          </Button>
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
          {schedules.map((schedule) => (
            <ScheduleCard
              key={schedule.id}
              schedule={schedule}
              device={getDeviceForSchedule(schedule.device_id)}
              onToggle={handleToggleSchedule}
              onEdit={handleEditSchedule}
              onDelete={confirmDelete}
            />
          ))}
        </div>
      )}

      <ScheduleFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        devices={devices}
        schedule={editingSchedule}
        onSave={handleSaveSchedule}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Schedule</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this schedule? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteSchedule}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
