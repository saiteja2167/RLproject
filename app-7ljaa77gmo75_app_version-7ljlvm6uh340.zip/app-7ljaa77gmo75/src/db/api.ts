import { supabase } from "./supabase";
import type {
  UserProfile,
  Device,
  DeviceSchedule,
  ConsumptionHistory,
  Recommendation,
} from "@/types/types";

export const getUserId = (): string => {
  let userId = localStorage.getItem("smart_grid_user_id");
  if (!userId) {
    userId = crypto.randomUUID();
    localStorage.setItem("smart_grid_user_id", userId);
  }
  return userId;
};

export const getUserProfile = async (userId: string): Promise<UserProfile | null> => {
  const { data, error } = await supabase
    .from("user_profiles")
    .select("*")
    .eq("id", userId)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const createUserProfile = async (userId: string): Promise<UserProfile> => {
  const { data, error } = await supabase
    .from("user_profiles")
    .insert({ id: userId })
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to create user profile");
  return data;
};

export const updateUserProfile = async (
  userId: string,
  updates: Partial<UserProfile>
): Promise<UserProfile> => {
  const { data, error } = await supabase
    .from("user_profiles")
    .update(updates)
    .eq("id", userId)
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to update user profile");
  return data;
};

export const getDevices = async (userId: string): Promise<Device[]> => {
  const { data, error } = await supabase
    .from("devices")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createDevice = async (device: Omit<Device, "id" | "created_at" | "updated_at">): Promise<Device> => {
  const { data, error } = await supabase
    .from("devices")
    .insert(device)
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to create device");
  return data;
};

export const updateDevice = async (
  deviceId: string,
  updates: Partial<Device>
): Promise<Device> => {
  const { data, error } = await supabase
    .from("devices")
    .update(updates)
    .eq("id", deviceId)
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to update device");
  return data;
};

export const deleteDevice = async (deviceId: string): Promise<void> => {
  const { error } = await supabase
    .from("devices")
    .delete()
    .eq("id", deviceId);

  if (error) throw error;
};

export const getDeviceSchedules = async (userId: string): Promise<DeviceSchedule[]> => {
  const { data, error } = await supabase
    .from("device_schedules")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createDeviceSchedule = async (
  schedule: Omit<DeviceSchedule, "id" | "created_at">
): Promise<DeviceSchedule> => {
  const { data, error } = await supabase
    .from("device_schedules")
    .insert(schedule)
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to create schedule");
  return data;
};

export const updateDeviceSchedule = async (
  scheduleId: string,
  updates: Partial<DeviceSchedule>
): Promise<DeviceSchedule> => {
  const { data, error } = await supabase
    .from("device_schedules")
    .update(updates)
    .eq("id", scheduleId)
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to update schedule");
  return data;
};

export const deleteDeviceSchedule = async (scheduleId: string): Promise<void> => {
  const { error } = await supabase
    .from("device_schedules")
    .delete()
    .eq("id", scheduleId);

  if (error) throw error;
};

export const getConsumptionHistory = async (
  userId: string,
  startDate?: Date,
  endDate?: Date,
  limit = 100
): Promise<ConsumptionHistory[]> => {
  let query = supabase
    .from("consumption_history")
    .select("*")
    .eq("user_id", userId);

  if (startDate) {
    query = query.gte("timestamp", startDate.toISOString());
  }
  if (endDate) {
    query = query.lte("timestamp", endDate.toISOString());
  }

  const { data, error } = await query
    .order("timestamp", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const addConsumptionRecord = async (
  record: Omit<ConsumptionHistory, "id">
): Promise<ConsumptionHistory> => {
  const { data, error } = await supabase
    .from("consumption_history")
    .insert(record)
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to add consumption record");
  return data;
};

export const getRecommendations = async (userId: string): Promise<Recommendation[]> => {
  const { data, error } = await supabase
    .from("recommendations")
    .select("*")
    .eq("user_id", userId)
    .eq("is_dismissed", false)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createRecommendation = async (
  recommendation: Omit<Recommendation, "id" | "created_at">
): Promise<Recommendation> => {
  const { data, error } = await supabase
    .from("recommendations")
    .insert(recommendation)
    .select()
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Failed to create recommendation");
  return data;
};

export const dismissRecommendation = async (recommendationId: string): Promise<void> => {
  const { error } = await supabase
    .from("recommendations")
    .update({ is_dismissed: true })
    .eq("id", recommendationId);

  if (error) throw error;
};
