export interface UserProfile {
  id: string;
  created_at: string;
  electricity_rate_peak: number;
  electricity_rate_offpeak: number;
  peak_hours_start: number;
  peak_hours_end: number;
  monthly_budget: number | null;
}

export interface Device {
  id: string;
  user_id: string;
  name: string;
  device_type: DeviceType;
  power_rating: number;
  is_active: boolean;
  is_schedulable: boolean;
  created_at: string;
  updated_at: string;
}

export type DeviceType = 
  | 'hvac'
  | 'water_heater'
  | 'ev_charger'
  | 'washer'
  | 'dryer'
  | 'dishwasher'
  | 'pool_pump'
  | 'lighting'
  | 'other';

export interface DeviceSchedule {
  id: string;
  device_id: string;
  user_id: string;
  schedule_name: string;
  start_time: string;
  duration_minutes: number;
  days_of_week: string[];
  is_enabled: boolean;
  created_at: string;
}

export interface ConsumptionHistory {
  id: string;
  user_id: string;
  device_id: string | null;
  timestamp: string;
  power_kw: number;
  energy_kwh: number;
  cost: number;
  is_peak_hour: boolean;
}

export interface Recommendation {
  id: string;
  user_id: string;
  title: string;
  description: string;
  potential_savings: number | null;
  priority: 'high' | 'medium' | 'low';
  is_dismissed: boolean;
  created_at: string;
}

export interface DashboardStats {
  currentPower: number;
  todayEnergy: number;
  todayCost: number;
  estimatedMonthlyCost: number;
  activeDevices: number;
  scheduledDevices: number;
  potentialSavings: number;
}

export interface ConsumptionDataPoint {
  timestamp: string;
  power: number;
  cost: number;
  isPeakHour: boolean;
}
