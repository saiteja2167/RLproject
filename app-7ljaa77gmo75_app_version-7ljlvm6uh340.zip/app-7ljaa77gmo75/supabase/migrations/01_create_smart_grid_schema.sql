/*
# Smart Grid Energy Optimizer Database Schema

## Overview
This migration creates the database structure for the Smart Grid Energy Optimizer application.
It uses UUID-based anonymous user identification to store user data without requiring authentication.

## 1. New Tables

### `user_profiles`
Stores anonymous user profiles identified by UUID
- `id` (uuid, primary key, default: gen_random_uuid())
- `created_at` (timestamptz, default: now())
- `electricity_rate_peak` (decimal, default: 0.25) - Peak hour rate per kWh
- `electricity_rate_offpeak` (decimal, default: 0.12) - Off-peak hour rate per kWh
- `peak_hours_start` (integer, default: 9) - Peak hours start (24h format)
- `peak_hours_end` (integer, default: 21) - Peak hours end (24h format)
- `monthly_budget` (decimal, nullable) - Optional monthly electricity budget

### `devices`
Stores smart devices/appliances for each user
- `id` (uuid, primary key, default: gen_random_uuid())
- `user_id` (uuid, references user_profiles)
- `name` (text, not null) - Device name
- `device_type` (text, not null) - Type: 'hvac', 'water_heater', 'ev_charger', 'washer', 'dryer', 'dishwasher', 'pool_pump', 'lighting', 'other'
- `power_rating` (decimal, not null) - Power consumption in kW
- `is_active` (boolean, default: true) - Current on/off state
- `is_schedulable` (boolean, default: true) - Can be scheduled
- `created_at` (timestamptz, default: now())
- `updated_at` (timestamptz, default: now())

### `device_schedules`
Stores scheduling rules for devices
- `id` (uuid, primary key, default: gen_random_uuid())
- `device_id` (uuid, references devices)
- `user_id` (uuid, references user_profiles)
- `schedule_name` (text, not null)
- `start_time` (time, not null) - When to turn on
- `duration_minutes` (integer, not null) - How long to run
- `days_of_week` (text[], not null) - Array of days: ['monday', 'tuesday', ...]
- `is_enabled` (boolean, default: true)
- `created_at` (timestamptz, default: now())

### `consumption_history`
Stores historical power consumption data
- `id` (uuid, primary key, default: gen_random_uuid())
- `user_id` (uuid, references user_profiles)
- `device_id` (uuid, references devices, nullable) - Null for total consumption
- `timestamp` (timestamptz, not null)
- `power_kw` (decimal, not null) - Instantaneous power in kW
- `energy_kwh` (decimal, not null) - Energy consumed in kWh for the period
- `cost` (decimal, not null) - Cost for the period
- `is_peak_hour` (boolean, not null)

### `recommendations`
Stores system-generated recommendations
- `id` (uuid, primary key, default: gen_random_uuid())
- `user_id` (uuid, references user_profiles)
- `title` (text, not null)
- `description` (text, not null)
- `potential_savings` (decimal, nullable) - Estimated savings in currency
- `priority` (text, default: 'medium') - 'high', 'medium', 'low'
- `is_dismissed` (boolean, default: false)
- `created_at` (timestamptz, default: now())

## 2. Security
- No RLS enabled - public access for all tables (anonymous UUID-based access)
- All users can read and write their own data based on user_id matching

## 3. Indexes
- Created indexes on user_id columns for faster queries
- Created index on consumption_history timestamp for time-series queries

## 4. Functions
- `update_device_timestamp()` - Trigger function to update devices.updated_at
*/

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  electricity_rate_peak decimal(10,4) DEFAULT 0.25,
  electricity_rate_offpeak decimal(10,4) DEFAULT 0.12,
  peak_hours_start integer DEFAULT 9,
  peak_hours_end integer DEFAULT 21,
  monthly_budget decimal(10,2)
);

-- Create devices table
CREATE TABLE IF NOT EXISTS devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  device_type text NOT NULL,
  power_rating decimal(10,3) NOT NULL,
  is_active boolean DEFAULT true,
  is_schedulable boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create device_schedules table
CREATE TABLE IF NOT EXISTS device_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id uuid NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  schedule_name text NOT NULL,
  start_time time NOT NULL,
  duration_minutes integer NOT NULL,
  days_of_week text[] NOT NULL,
  is_enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create consumption_history table
CREATE TABLE IF NOT EXISTS consumption_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  device_id uuid REFERENCES devices(id) ON DELETE SET NULL,
  timestamp timestamptz NOT NULL,
  power_kw decimal(10,3) NOT NULL,
  energy_kwh decimal(10,4) NOT NULL,
  cost decimal(10,4) NOT NULL,
  is_peak_hour boolean NOT NULL
);

-- Create recommendations table
CREATE TABLE IF NOT EXISTS recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  potential_savings decimal(10,2),
  priority text DEFAULT 'medium',
  is_dismissed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_devices_user_id ON devices(user_id);
CREATE INDEX IF NOT EXISTS idx_device_schedules_user_id ON device_schedules(user_id);
CREATE INDEX IF NOT EXISTS idx_device_schedules_device_id ON device_schedules(device_id);
CREATE INDEX IF NOT EXISTS idx_consumption_history_user_id ON consumption_history(user_id);
CREATE INDEX IF NOT EXISTS idx_consumption_history_timestamp ON consumption_history(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_consumption_history_device_id ON consumption_history(device_id);
CREATE INDEX IF NOT EXISTS idx_recommendations_user_id ON recommendations(user_id);

-- Create trigger function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_device_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for devices table
CREATE TRIGGER update_devices_timestamp
BEFORE UPDATE ON devices
FOR EACH ROW
EXECUTE FUNCTION update_device_timestamp();
