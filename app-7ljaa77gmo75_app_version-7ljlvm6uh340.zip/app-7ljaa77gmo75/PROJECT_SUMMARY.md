# Smart Grid Energy Optimizer

A comprehensive web-based smart grid electricity management system that helps users monitor real-time power consumption, automatically control smart devices, and optimize electricity usage to reduce utility bills.

## 🌟 Key Features

### 1. Real-Time Power Monitoring
- Live power consumption display with animated gauges
- Instantaneous power metrics (kW/kWh)
- Visual energy flow tracking
- Peak hour indicators

### 2. Smart Device Management
- Add and manage multiple smart devices
- Support for various device types:
  - HVAC systems
  - Water heaters
  - EV chargers
  - Washers and dryers
  - Dishwashers
  - Pool pumps
  - Lighting systems
- Real-time device control (on/off)
- Power rating tracking

### 3. Intelligent Scheduling
- Automatic appliance scheduling during off-peak hours
- Customizable schedules with:
  - Specific start times
  - Duration settings
  - Day-of-week selection
- Enable/disable schedules on demand
- Manual override capabilities

### 4. Comprehensive Reports & Analytics
- Weekly and monthly consumption trends
- Cost analysis and projections
- Device-by-device usage breakdown
- Peak vs off-peak hour comparisons
- Interactive charts and visualizations

### 5. Smart Recommendations
- AI-powered energy-saving suggestions
- Potential savings calculations
- Priority-based recommendations
- Actionable insights for cost reduction

### 6. Customizable Settings
- Configure electricity rates (peak and off-peak)
- Set peak hour windows
- Define monthly budget targets
- Personalized optimization parameters

## 🎨 Design Highlights

### Color Scheme
- **Primary**: Deep Blue (#1E3A8A) - Representing energy and technology
- **Secondary**: Bright Green (#10B981) - Indicating savings and efficiency
- **Accent**: Amber (#F59E0B) - For alerts and peak hour warnings
- **Background**: Light Gray (#F3F4F6) with white content cards

### User Interface
- Modern card-based layout
- Real-time animated graphs and charts
- Clean, intuitive navigation
- Responsive design for all devices
- Dark mode support
- Smooth transitions and interactions

## 🛠️ Technical Architecture

### Frontend Stack
- **React 18** with TypeScript
- **Vite** for fast development and building
- **Tailwind CSS** for styling
- **shadcn/ui** component library
- **Recharts** for data visualization
- **React Router** for navigation

### Backend & Database
- **Supabase** for backend services
- **PostgreSQL** database
- UUID-based anonymous user identification
- Real-time data synchronization

### Database Schema
- **user_profiles**: User preferences and settings
- **devices**: Smart device inventory
- **device_schedules**: Scheduling configurations
- **consumption_history**: Historical energy data
- **recommendations**: AI-generated suggestions

## 📊 Core Functionality

### Dashboard
- At-a-glance energy consumption metrics
- Current power usage gauge
- 24-hour consumption chart
- Active device count
- Cost projections
- Smart recommendations feed

### Device Management
- Visual device cards with status indicators
- Quick toggle controls
- Device editing and deletion
- Power rating display
- Schedulable device identification

### Scheduling System
- Create custom schedules for each device
- Multi-day schedule support
- Time-based automation
- Off-peak optimization
- Schedule enable/disable controls

### Reports
- Multiple visualization types:
  - Bar charts for consumption
  - Line charts for cost trends
  - Pie charts for device breakdown
  - Comparative analysis
- Exportable data (future enhancement)
- Historical trend analysis

### Settings
- Electricity rate configuration
- Peak hour window definition
- Monthly budget setting
- Profile customization

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ installed
- pnpm package manager

### Installation
```bash
# Install dependencies
pnpm install

# Start development server
pnpm run dev

# Build for production
pnpm run build

# Run linting
pnpm run lint
```

### Environment Variables
The application uses Supabase for backend services. Environment variables are configured in `.env`:
- `VITE_SUPABASE_URL`: Supabase project URL
- `VITE_SUPABASE_ANON_KEY`: Supabase anonymous key

## 💡 Usage Tips

1. **First Time Setup**
   - The app automatically creates a user profile on first visit
   - Default electricity rates are pre-configured
   - Sample recommendations are provided

2. **Adding Devices**
   - Navigate to the Devices page
   - Click "Add Device"
   - Enter device details and power rating
   - Mark as schedulable if needed

3. **Creating Schedules**
   - Go to the Schedules page
   - Click "Create Schedule"
   - Select a device and set timing
   - Choose days of the week
   - Enable the schedule

4. **Optimizing Costs**
   - Review recommendations on the Dashboard
   - Schedule high-power devices during off-peak hours
   - Monitor the Reports page for usage patterns
   - Adjust settings based on your utility rates

## 🔒 Privacy & Data

- **Anonymous Usage**: No login required
- **Local Storage**: User ID stored locally in browser
- **Data Isolation**: Each user's data is completely separate
- **No Tracking**: No analytics or user tracking implemented

## 🎯 Future Enhancements

- Real device integration via smart home APIs
- Machine learning for predictive scheduling
- Weather-based optimization
- Solar panel integration
- Export reports to PDF/Excel
- Mobile app version
- Multi-location support
- Energy provider integration

## 📈 Performance

- Fast initial load with code splitting
- Optimized re-renders with React hooks
- Efficient data fetching with Supabase
- Responsive charts with Recharts
- Smooth animations with Tailwind CSS

## 🤝 Contributing

This is a demonstration project showcasing modern web development practices with React, TypeScript, and Supabase.

## 📄 License

This project is created for demonstration purposes.

---

**Built with ⚡ by Miaoda AI**
